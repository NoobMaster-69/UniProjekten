#-------------------------------------------------
#
# Project created by QtCreator 2017-03-26T11:05:53
#
#-------------------------------------------------

QT       += core

QT       -= gui

TARGET = konsolenanwendung
CONFIG   += console
CONFIG   -= app_bundle

TEMPLATE = app


SOURCES += \
    main.c
