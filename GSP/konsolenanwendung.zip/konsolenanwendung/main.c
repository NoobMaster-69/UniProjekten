// In dieser C-Source-Code-Datei sind
// Beispiele aufgeführt, die sich an denen aus dem Skript orientieren.
// Im Gegensatz zu den beispielen aus dem Skript (die ohne Standard-IO-Funktionen auskommen muessen),
// sind die hier aufgefuehrten Beispiele bewusst mit deren Verwendung ausgefuehrt.
//
// Aus historischen Gruenden unterscheidet sich die hier verwendete Nummerierung der Beispiele
// von der NUmmerierung aus dem Skript.
//
// Jedes Beispiel ist in ein
// #ifdef beispiel_x
// ...
// #endif // beispiel_x
// eingebettet.
//
// Diese Einbettung erlaubt eine
// bedingte Compilierung, d.h. der Source-Code
// der zwischen  #ifdef beispiel_x  und  #endif // beispiel_x
// steht wird nur dann compiliert(vom Compiler "gesehen" und in ausführbaren
// Code umgewandel), wenn vorher im Source-Code beispiel_x
// definiert wurde.
//
// Man definiert beispiel_x durch die folgende Zeile:
// #define beispiel_x
//
// Um das Beispiel 2 zu compilieren muss also die Zeile
// #define beispiel_1
// in
// #define beispiel_2
// abgeaendert werden.
//
// Die gleichzeitige Definition, z.B. von beispiel_1 und beispiel_2
// durch
// #define beispiel_1
// #define beispiel_2
// macht hier keinen Sinn, denn dann wuerde der vom Compiler "gesehene"
// Source-Code zweimal die Funktion main enthalten. Das wuerde zu einer
// Fehlermeldung fuehren.
//
// Die define-Anweisung kann auch dazu genutzt werden um sogenannte
// Makros zu definieren. Makros sind Platzhalter für Textsegmente.
// Diese Makros (Platzhalter) werden vom Compiler (dessen Präprozessor)
// vor der eigentlichen Compilierung durch das Textsegment ersetzt.
// Beispiel:
// #define WARTE_AUF_TASTENDRUCK getch()
// Vor der Compilierung wird überall** dort wo das Makro WARTE_AUF_TASTENDRUCK
// im Source-Code steht dieses durch getch() ersetzt.
// **Bem.: Fast überall, denn innerhalb vom Makros und innerhalb von
//        Variablen- und Funktionsname sowie innerhalb von String-Konstanten
//        wird keine Ersetzung vorgenommen.
//
// Unter der Entwicklungsumgebung Visual-Studio  wird beim Start einer Consolenanwendung (z.B. durch
// Doppeclick mit der rechten Maustaste auf das Symbol der Consolenanwnedung,
// oder durch Starten des Consolenanwendung aus eine Entwicklungsumgebung
// heraus)automatisch zunächst die Console und dann innerhalb der Console die
// Consolenanwendung gestartet.
// Nach Beendigung der Consolenanwendung wird eine so gestartete Console
// auch automatisch sofort beendet.
// Aus diesem Grund sind alle hier aufgeführten Beispiele mit einem
// WARTE_AUF_TASTENDRUCK; bzw. getch();
// abgeschlosen, so dass Ausgaben der Consolenanwendung bis zur Betätigung
// einer Taste stehen bleiben und gelesen werden können.
//
// Bei anderen Entwicklungsumgebungen (z:B. Qt) kann dies anders sein.


#define beispiel_1
//#define beispiel_2
//#define beispiel_3
//#define beispiel_4
//#define beispiel_5
//#define beispiel_6
//#define beispiel_7
//#define beispiel_8
//#define beispiel_9
//#define beispiel_10
//#define beispiel_11
//#define beispiel_12a
//#define beispiel_12b
//#define beispiel_12c
//#define beispiel_13
//#define beispiel_17
//#define beispiel_18
//#define beispiel_20
//#define beispiel_21
//#define beispiel_22







#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <conio.h>

#define WARTE_AUF_TASTENDRUCK //getch() //In Qt nicht notwendig wenn die Anwendung aus Qt heraus gestartet wird




#ifdef beispiel_1
main ()
{
    /* Deklarationsteil Anfang*/
    long int		zahl1=2;
    long int		zahl2=4;
    const long int	drei=3;
    long int		ergebnis;
    /* Deklarationsteil Ende */

    /* Ausführungsteil Anfang */
    zahl2 = zahl1 + zahl2;
    ergebnis = zahl2 * drei;
    printf("ergebnis=%d\n", ergebnis);
    WARTE_AUF_TASTENDRUCK;
    // Ausführungsteil Ende
}
#endif // beispiel_1


#ifdef beispiel_2
main() {
    long int zahl1;
    long int zahl2;
    long int ergebnis;


    printf("Bitte geben Sie eine ganze Zahl ein:\n");
    scanf("%d", &zahl1);
    printf("Bitte geben Sie eine ganze Zahl ein:\n");
    scanf("%d", &zahl2);

    ergebnis= zahl1 * zahl2;

    printf("Das Produkt der beiden Zahlen ist %d\n", ergebnis);

    WARTE_AUF_TASTENDRUCK;
}
#endif // beispiel_2


#ifdef beispiel_3
main()
{
  long int i=4;

  while (i>=0)
  {
    printf ("%d\n", i); /* Diese Anweisung gibt den Wert von i*/
                        /* auf dem Monitor aus, wobei nach Aus-*/
                        /* gabe, wegen "\n", ein Zeilenvorschub */
                         /* durchgeführt wird. */
    i=i-1;
  }
  WARTE_AUF_TASTENDRUCK;
}
#endif // beispiel_3


#ifdef beispiel_4
main()
{
  long int i=-1;
  do
  {
    printf ("%d\n", i); /* Diese Anweisung gibt den Wert von i*/
                        /* auf dem Monitor aus */
    i=i-1;
  } while (i >=0);
  WARTE_AUF_TASTENDRUCK;
}
#endif // beispiel_4


#ifdef beispiel_5
main()
{
  long int i;

  for (i=4; i>=0; i=i-1)
  {
    printf ("%d\n", i); /* Diese Anweisung gibt den Wert von i*/
                        /* auf dem Monitor aus */
  }
  WARTE_AUF_TASTENDRUCK;
}
#endif // beispiel_5


#ifdef beispiel_6
main()
{
  long int i;

  printf("Wert fuer i eingeben: ");	/* Hier wird der Wert von i */
    scanf("%d", &i);	            /* irgendwie verändert. */


  if (i >=0)
  {
    printf ("i ist positiv\n");
  }
  else
  {
    printf ("i ist negativ\n");
  }
  WARTE_AUF_TASTENDRUCK;
}
#endif // beispiel_6


#ifdef beispiel_7
main()
{
  long int i;

  for (i=4; i>=0; i=i-1)
  {
    if (i!=2)
        printf ("%d\n", i);
    else
        break;
  }
  WARTE_AUF_TASTENDRUCK;
}
#endif // beispiel_7


#ifdef beispiel_8
main()
{
  long int i;

  for (i=4; i>=0; i=i-1)
  {
    if (i!=2)
        printf ("%d\n", i);
    else
        continue;
  }
  WARTE_AUF_TASTENDRUCK;
}
#endif // beispiel_8


#ifdef beispiel_9
main()
{
  long int i=4;
  printf("Wert fuer i eingeben: ");	/* Hier wird der Wert von i */
  scanf("%d", &i);	            /* irgendwie verändert. */

  switch( i )
    {
        case 1: printf( "Eins\n"); break;
        case 2: printf( "Zwei\n"); break;
        case 3: printf( "Drei\n"); break;
        case 4: printf( "Vier\n"); break;
        case 5: printf( "Fuenf\n"); break;
        default: printf( "Kleiner Eins oder groesser Fuenf\n");
    }
   WARTE_AUF_TASTENDRUCK;
}
#endif // beispiel_9


#ifdef beispiel_10
main()
{
    long int i=4;

    printf("Wert fuer i eingeben: ");	/* Hier wird der Wert von i */
    scanf("%d", &i);	                /* irgendwie verändert. */

    switch( i )
    {
    case 1: printf( "Eins\n");
        case 2: printf( "Zwei\n");
        case 3: printf( "Drei\n");
        case 4: printf( "Vier\n");
        case 5: printf( "Fuenf\n");
        default: printf( "Kleiner Eins oder groesser Fuenf\n");
    }
    WARTE_AUF_TASTENDRUCK;
}
#endif // beispiel_10


#ifdef beispiel_11
main()
{
  long int messwerte [10];  /* Meldet ein Feld von  */
                            /* 10 Integerwerten an. */

  long int tabelle[3] = {1, 2, 3}; 	/* Meldet ein Feld von */
                                    /*  3 Integerwerten an und weist dem *
                                    /* 1. Feldelement den Wert 1, dem */
                                    /* 2. Feldelement den Wert 2 und dem */
                                    /* 3. Feldelement den Wert 3 zu. */

  messwerte [0] = tabelle[2];   /* Weist dem 1. Feldelement von messwerte */
                                /* den Wert des 3. Feldelementes von tabelle zu. */

  messwerte [1] = messwerte [0]; /* Liest den Wert des 1.
                                 /* Feldelementes und weist diesen Wert */
                                 /* dem 2. Feldelement zu. */
  printf("messwerte[0]=%d\n", messwerte[1]);
  printf("messwerte[1]=%d\n", messwerte[1]);
  WARTE_AUF_TASTENDRUCK;
  }
#endif // beispiel_11


#ifdef beispiel_12a
main()
{
  long int zaehler=0x80C80000;

  printf ("Adresse von zaehler ist: 0x%p \n", 	&zaehler );
  printf ("Wert von zaehler ist: 0x%x \n", 		 zaehler   );
  WARTE_AUF_TASTENDRUCK;
}
#endif // beispiel_12a


#ifdef beispiel_12b
main()
{
  long int zaehler=0x80C80000;
  long int *zeiger; /* 1.) Meldet einen Zeiger an, der auf */
                    /* long-int-Variablen zeigen kann. Der Zeiger */
                    /* ist noch nicht initialisiert, d.h. er zeigt noch */
                    /* nicht auf irgendeine bestimmte Variable.*/

  zeiger = &zaehler; 	/* 2.) Der Zeiger wird so initialisiert, */
                        /* dass er auf die Adresse der */
                        /* Variablen zaehler zeigt. */

  printf ("Adresse von zaehler ist: 0x%p\n", 	 zeiger ); 	/* 3.) */
  printf ("Wert von zaehler ist: 0x%x\n",  	*zeiger );      /* 4.) */
  printf ("Adresse von zeiger ist: 0x%p\n", 	&zeiger);	/* 5.) */
  WARTE_AUF_TASTENDRUCK;
}
#endif // beispiel_12b


#ifdef beispiel_12c
main() {
    long int *zeiger;   /* 1.) Deklaration einer Zeiger-Variablen*/

    long int messwerte [3] = {0xF532, 0xA738, 0x3914};  /* 2.) Meldet ein Feld von drei */
                                                        /* Long-Integerwerten an und initialisiert */
                                                        /* es mit den angegebenen HEX-Werten */

    zeiger = &messwerte [0];    /* 3.) Der Zeiger wird so initiali- */
                                /* siert,dass er auf das Byte mit der niedrigsten */
                                /* Adresse  des ersten  Feldelementes des */
                                /* Feldes messwerte zeigt. */

    zeiger++;                   /* 4.) Nach dieser Operation zeigt der Zeiger */
                                /* auf das Byte mit der niedrigsten Adresse */
                                /* des zweiten Feldelemente des Feldes */
                                /* messwerte. Da Variablen vom */
                                /* Typ long-int 4 Bytes umfassen und der */
                                /* Zeiger vom Typ long-int ist, wurde dessen */
                                /* Wert nicht um 1 sondern um 4 erhöht. */

    *zeiger = 4;                /* 5.) Mit dieser Operation wird der Wert 4 */
                                /* in das Feldelement "messwerte [1]" */
                                /* geschrieben */

    printf("messwerte[1]=%d\n", messwerte[1]);
    WARTE_AUF_TASTENDRUCK;
}
#endif // beispiel_12c


#ifdef beispiel_13
main(){

    struct strc_complex
    {
        double real;
        double imag;
    };
    typedef struct strc_complex complex;

    double buffer;

    /* Verkürzend schreibt man üblicherweise wie folgt:*/
    /* typedef struct strc_complex	*/
    /* {							*/
    /*	double real;				*/
    /*	double imag;				*/
    /* } complex;					*/

    complex x;

    x.real = 7.0;
    x.imag = 6.4;

    // Vetauschem von Real- und Imaginärteil
    buffer = x.real;
    x.real = x.imag;
    x.imag = buffer;

    printf("x.real=%f  x.imag=%f\n", x.real, x.imag);
    WARTE_AUF_TASTENDRUCK;
}
#endif // beispiel_13



#ifdef beispiel_17
/* Definition der Funktion vor dem ersten Aufruf */
float produkt2 (float faktor1, float faktor2)
{
    float temp;
    temp = faktor1 * faktor2;
    faktor2 = faktor2 + 1;
    return (temp);
}

main()
{
    float laenge;
    float breite;
    float flaeche;

    /* Hier werden die Variablen "laenge" und "breite" */
    /* irgendwie mit sinnvollen Werten "gefüllt" */
    printf("Wert fuer laenge eingeben: ");
    scanf("%f", &laenge);
    printf("Wert fuer breite eingeben: ");
    scanf("%f", &breite);


    flaeche = produkt2 (laenge, breite);    /* Die Funktion "produkt" */
                                            /* wird aufgerufen. Dabei werden der Funktion  */
                                            /* eine Kopie die Werte von "laenge" und "breite" */
                                            /* übergeben. Die Funktion berechnet das Produkt */
                                            /* der beiden Werte und gibt dies als Ergebnis */
                                            /* zurück. Die Variable "flaeche" wird mit dem */
                                            /* Rückgabewert initialisiert */

    printf("flaeche=%f\n", flaeche);
  WARTE_AUF_TASTENDRUCK;
}
#endif // beispiel_17


#ifdef beispiel_18
long int mich_kennen_alle;  /* Definition einer globalen Variablen, */
                            /* die in dem gezeigten */
                            /* in diesem Source-Code genutzt wrid. */

float produkt3 (float faktor1, float* faktor2)
{
    float temp;
    temp = faktor1 * *faktor2;
    *faktor2 = *faktor2 + 1;
    mich_kennen_alle++;
    return (temp);
}

main()
{
    float laenge;
    float breite;
    float flaeche;

  /* Hier werden die Variablen "laenge" und "breite" */
  /* irgendwie mit sinnvollen Werten "gefüllt" */
  printf("Wert fuer laenge eingeben: ");
    scanf("%f", &laenge);
  printf("Wert fuer breite eingeben: ");
    scanf("%f", &breite);

    mich_kennen_alle=1;

    flaeche = produkt3 (laenge, &breite);   /* Die Funktion */
                                            /* "produkt3" wird aufgerufen. Dabei werden der */
                                            /* Funktion eine Kopie des Werte von "laenge" */
                                            /* und die Adresse der Speicherstelle der Variablen
                                            /* "breite" übergeben* /

                                            /* Die Funktion berechnet das Produkt der beiden
                                            /* Werte und gibt dies als  Ergebnis zurück. Die */
                                            /* Variable "flaeche" wird mit dem Rückgabewert */
                                            /* initialisiert. Nach dem  Funktionsaufruf ist der */
                                            /* Wert der variable "breite" um 1 erhöht. */
                                            /* Auch die globale Variable ist nach dem */
                                            /* Funktionsaufruf um 1 erhöht. */

    printf("flaeche=%f\n", flaeche);
    printf("breite=%f\n", breite);
    printf("mich_kennen_alle=%d\n", mich_kennen_alle);
    WARTE_AUF_TASTENDRUCK;
}
#endif // beispiel_18


#ifdef beispiel_20
main()
{
  float  float_var;
  double double_var;
  unsigned long int unsigned_long_int_var;
  long int long_int_var;
  char char_var;
  unsigned long int* p_unsigned_long_int;

  float_var=-480.6875;  // Diese Float-Variable hat im Speicher das folgende
                        // hexadezimale "Aussehen":  0xC3F05800
  printf("Floatwert:long_int_var=%f\n\n",float_var);

  long_int_var = (long int) float_var;  // long_int_var=float_var;

  printf("Interpretation von   long_int_var           als:\n");
  printf("vorzeichenbehafteter Dezimalwert: %d\n",long_int_var);
  printf("vorzeichenloser Dezimalwert:      %u\n",long_int_var);
  printf("vorzeichenloser Hexadezimalwert:  0x%X\n\n",long_int_var);


  unsigned_long_int_var = (unsigned long int)float_var;
                            //unsigned_long_int_var=float_var;
  printf("Interpretation von   unsigned_long_int_var  als:\n");
  printf("vorzeichenbehafteter Dezimalwert: %d\n",unsigned_long_int_var);
  printf("vorzeichenloser Dezimalwert:      %u\n",unsigned_long_int_var);
  printf("vorzeichenl. Hexadezimalwert:  0x%X\n\n",unsigned_long_int_var);


  char_var = (char) float_var;  		// char_var=float_var;

  printf("Interpretation von   char_var               als:\n");
  printf("vorzeichenbehafteter Dezimalwert: %d\n",char_var);
  printf("vorzeichenloser Dezimalwert:      %u\n",char_var);
  printf("vorzeichenloser Hexadezimalwert:  0x%X\n\n",char_var);


  p_unsigned_long_int= (unsigned long int*) &float_var;
                            // p_unsigned_long_int=&float_var;
  unsigned_long_int_var=*p_unsigned_long_int;
  printf("Interpretat. v. unsigned_long_int_var=*p_unsigned_long_int als:\n");
  printf("vorzeichenbehafteter Dezimalwert: %d\n",unsigned_long_int_var);
  printf("vorzeichenloser Dezimalwert:      %u\n",unsigned_long_int_var);
  printf("vorzeichenl. Hexadezimalwert:  0x%X\n\n",unsigned_long_int_var);

   WARTE_AUF_TASTENDRUCK;
}
#endif // beispiel_20



#ifdef beispiel_21
//	Im folgenden eine erste relativ kleine Anwendung mit echtem Nutzen.
//	Diese Anwendung soll dazu dienen für eine Klausur die Notenlisten
//	zu erstellen.
//
//	Diese Anwendung erfüllt zwar diesen Zweck, ist aber nicht wirklich
//	nutzbar, denn z.B. werden die Eingaben nicht überprüft. Eine echte
//	Anwendung (ein echtes Produkt) darf sich dies nicht erlauben!
//
//	Als Beispiel für die Anwendung verschiedenster C-Konstrukte
//	und Standardbibliotheken sollte dieser Source-Code jedoch ausreichen.

#define STRINGMAX 100

// Definition eines Datentyps der den Eintrag für einen
// Studenten aufnehmen kann.
typedef struct _student {
        char name[STRINGMAX];
        char vorname[STRINGMAX];
        long int matr_nr;
        long int punkte;
        float note;
} student;


// Da die Funktion berechne_noten() in der Source-Code-Datei unterhalb
// der Zeile steht in der sie das erste mal aufgerufen wird, muss die
// Schnittstelle der Funktion vorher (also hier) deklariert werden.
int berechne_noten(long int anzahl, student* p_str_feld);


main()
{
    long int anzahl, i, ret;
    char fach[STRINGMAX];
    char datei_name[STRINGMAX];
    char ja_nein[STRINGMAX];
    char buffer[STRINGMAX];
    FILE* fp;

    student* p_feld;
    student* p_feld_merker;

    printf("Wieviele Noten wollen Sie melden? ");
    scanf("%d", &anzahl);


    // 1.) Feld für die Notenmeldungen allokieren
    // Es wird soviel Platz allokiert wie Noten gemeldet werden sollen.
    p_feld_merker=(student*) malloc(sizeof(student ) * anzahl);

    if (p_feld_merker==NULL) {
       fprintf (stderr,"ERROR: Feld für Notenmeldung konnte nicht allokiert werden\n");
       fflush (stderr); WARTE_AUF_TASTENDRUCK;
       return(-1);	// stderr ist ein sogenannter Stream.
                    // Auf einen Stream kann genauso (geschrieben werden
                    // wie in eine Datei. Der Stream stderr wird bei
                    // Programmstart implizit geöffnet und bei
                    // Programmende impliit geschlossen.
                    // stderr ist über Einstellung so definiert, dass
                    // auf die Konsole ausgegeben wird, kann
                    // aber auch in eine Datei umgelenkt werden.
    }
    p_feld=p_feld_merker;


    // 2.) Textdatei anlegen in die die Notenmeldungen
    // geschrieben werden sollen
    printf("Bitte den Namen der Ausgabedatei angeben.\n");
    scanf("%s", &(datei_name[0]));

    fp=fopen(datei_name, "r");

    if(fp==NULL) {
        printf ("Die Ausgabedatei existiert nicht.\n");
        printf ("Soll die Datei angelegt werden? (ja/nein)\n");
        scanf("%s", ja_nein );	// Anstelle von &(ja_nein[0]) darf auch
                                // kurz ja_nein geschrieben werden.

        ret=strcmp(ja_nein,"ja");   // Testen, ob ja eingegeben wurde
        if(ret==0){
            fp=fopen(datei_name, "wt");
        }
        else {
            return(-1);
        }
    }
    else {
        fclose(fp); // Datei schließen damit sie im
                    // anhängenden Schreibmodus sofort
                    // wieder geöffnet werden kann.
        fp=fopen(datei_name, "at");
        if(fp==NULL) {
            fprintf (stderr,"Error: Ausgabedatei konnte nicht angelegt werden\n");
            fflush(stderr);
            return(-1);
        }

    }


    // 3.) Eingabe der Daten und deren Ablage im Feld
    printf("Bitte den Namen des Faches eingeben fuer das die Noten gemeldet werden:\n");
    scanf("%s", &(fach[0]));

    fprintf(fp,"Notenmeldung für das Fach: %s\n\n", fach);

    for(i=0;i<anzahl;i++) {
        printf("Bitte den %d. Datensatz eingeben\n", i+1);
        printf("Name: \n");
        scanf("%s",  &(p_feld[i].name));
        printf("Vorname: \n");
        scanf("%s",  &(p_feld[i].vorname));
        printf("Matrikel-Nr.: \n");
        scanf("%d",  &(p_feld[i].matr_nr));
        printf("Punkte: \n");
        scanf("%d", &(p_feld[i].punkte));
    }


    // 4.) Berechnung der Noten
    ret=berechne_noten(anzahl, p_feld);

    if(ret!=0) {
        fprintf (stderr, "ERROR: Die Noten konnten nicht berechnet werden\n");
        fflush(stderr);
    }


    // 5.) Schreiben der bearbeiteten Daten in die Datei
    sprintf(buffer,"%-20s %-20s     %-10s     %-4s\n", "Name", "Vorname", "Matr.-Nr.", "Note");
    fprintf(fp,"%s\n",buffer);

    for(i=0;i<anzahl;i++) {
        fprintf(fp,"%-20s %-20s     %-10d     %-1.1f\n", p_feld[i].name, p_feld[i].vorname, \
                    p_feld[i].matr_nr, p_feld[i].note);
    }

    // 6.) Freigabe des allokierten Speichers
    // Sicherheitshalber wurde sich die Anfangsadresse des allokierten Speichers
    // gemerkt, so das p_feld durchaus hätte verändert werden dürfen.
    free(p_feld_merker);

    // 7.) Schließen der Ausgabedatei
    if(fclose(fp)!=0) {
        fprintf (stderr, "ERROR: Die Ausgabedatei konnte nicht geschlossen werden\n");
        fflush(stderr);
    }
    else {
        printf("Die Ausgabedatei wurde erstellt.\n");
    }

    WARTE_AUF_TASTENDRUCK;
    return(0);
}


/*	Funktion zur Berechnung der Note aus der Punktezahl
    Übergabene Parameter:
    p_str_feld:		Zeiger auf das Feld von Strukturen (Typ student)
                    in dem u.a. die Punktezahlen eingetragen sind
    anzahl:			Anzahl gülter Einträge im Feld auf das p_str_feld zeigt
    return:			0 wenn alles o.k.; -1 wenn anzahl <0
*/
int berechne_noten(long int anzahl, student* p_str_feld) {
    long int i;
    long int max_punkte, bestehens_grenze, intervall_laenge;

    if(anzahl<=0)
        return(-1);

    // Zur Notenbestimmng wird zunächst die höchste erreichte Punktezahl (max_punkte) bestimmt.
    // Die Hälft von max_punkte ist die Bestehensgrenze.
    // Der Punktebereich zwischen der Bestehensgrenze und der höchsten erreichten Punktezahl
    // wird möglichst gleichmäßig auf die Noten 4.0, 3.7, 3.3, 3.0, 2.7, 2.3, 2.0, 1.7
    // 1.3, 1.0 verteilt. Hierzu werden 10 entsprechende Notenintervalle berechnet.
    // DIESER ALGORITHMUS SOLL NUR ALS BEISPIEL DIENEN

    // Bestimmung der höchsten erreichten Punktezahl
    max_punkte=p_str_feld[0].punkte;

    for(i=0;i<anzahl;i++) {

        max_punkte=(max_punkte<p_str_feld[i].punkte) ? p_str_feld[i].punkte : max_punkte;

        // Statt dieser schwer zu lesenden Zeile könnte man auch das folgende schreiben:
        //	if(max_punkte<p_str_feld[i].punkte)
        //		max_punkte=p_str_feld[i].punkte;
        //	else
        //		max_punkte=max_punkte; // Der else-Zweig ist hier eigentlich überflüssig.
    }

    printf("max_punkte=%d\n", max_punkte);

    // Bestimmung der Größe der Notenintervalle und der Bestehendgrenze
    bestehens_grenze = max_punkte/2;
    intervall_laenge = (max_punkte - bestehens_grenze)/10;

    // Zuteilung der Punktezahl zu einer Note einem Notenintervall
    for(i=0;i<anzahl;i++) {
        if(p_str_feld->punkte<bestehens_grenze)
            p_str_feld->note=(float) 5.0;
        if( (p_str_feld->punkte>=bestehens_grenze)  && (p_str_feld->punkte<(bestehens_grenze+1*intervall_laenge))  )
            p_str_feld->note=(float)4.0;
        if( (p_str_feld->punkte>=(bestehens_grenze+1*intervall_laenge))  && (p_str_feld->punkte<(bestehens_grenze+2*intervall_laenge))  )
            p_str_feld->note=(float) 3.7;
        if( (p_str_feld->punkte>=(bestehens_grenze+2*intervall_laenge))  && (p_str_feld->punkte<(bestehens_grenze+3*intervall_laenge))  )
            p_str_feld->note=(float) 3.3;
        if( (p_str_feld->punkte>=(bestehens_grenze+3*intervall_laenge))  && (p_str_feld->punkte<(bestehens_grenze+4*intervall_laenge))  )
            p_str_feld->note=(float) 3.0;
        if( (p_str_feld->punkte>=(bestehens_grenze+4*intervall_laenge))  && (p_str_feld->punkte<(bestehens_grenze+5*intervall_laenge))  )
            p_str_feld->note=(float) 2.7;
        if( (p_str_feld->punkte>=(bestehens_grenze+5*intervall_laenge))  && (p_str_feld->punkte<(bestehens_grenze+6*intervall_laenge))  )
            p_str_feld->note=(float) 2.3;
        if( (p_str_feld->punkte>=(bestehens_grenze+6*intervall_laenge))  && (p_str_feld->punkte<(bestehens_grenze+7*intervall_laenge))  )
            p_str_feld->note=(float) 2.0;
        if( (p_str_feld->punkte>=(bestehens_grenze+7*intervall_laenge))  && (p_str_feld->punkte<(bestehens_grenze+8*intervall_laenge))  )
            p_str_feld->note=(float) 1.7;
        if( (p_str_feld->punkte>=(bestehens_grenze+8*intervall_laenge))  && (p_str_feld->punkte<(bestehens_grenze+9*intervall_laenge))  )
            p_str_feld->note=(float) 1.3;
        if( (p_str_feld->punkte>=(bestehens_grenze+9*intervall_laenge)) )
            p_str_feld->note=(float) 1.0;

        p_str_feld++; // Zeiger auf das nächste Feldelement "biegen".
    }

    return(0);

}
#endif // beispiel_21


#ifdef beispiel_22
/*
Das folgende Programm inklusive der vorengestellten Erläuterungen
zeigt die Implementierung eines FIFOs unter Verwendung einer einfach
verketteten Liste.

Das Prinzip gestaltet sich wie folgt:

Ein Listenelement einer einfach verketteten Liste besteht immer aus einem:

    - Nutzanteil (nutzinfo), der die zu speichernde Information enthält und
    - Verwaltungsanteil (*next), d.h ein Zeiger auf das nächste Listenelement

Es ist zweckmäßig in C für ein Listenelement eine entsprechende Struktur
zu definieren (listenelement).



Wird die einfach verkettete Liste zur Realisierung eines FIFOs gebraucht, so
ist es zweckmäßig sich das erste und letzte Element in der verketteten List
zu "merken", so das man direkt darauf zugreifen kann. Eine Alternative
wäre es sich nur das erste Element zu merken, denn das letzte Element kann man
"erreichen" indem man sich durch die ganze Liste (vom Anfang zum Ende) "durchhangelt".

In C kann man dieses "merken" durch einen Zeiger auf das erste (*erstes_element)
und das letzte Listenelement (*letztes_element) realisieren.

Darüber hinaus ist es sinnvoll Buch darüber zu führen wieviele Elemente schon
im FIFO bzw. in der verketteten Liste sind. Man merkt sich also den Füllstand
(fuellstand) des FIFOs.

Es ist zweckmäßig die zu merken (zu verwaltenden) Daten des FIFOs in einer
entsprechenden Struktur zu halten (fifo_verwaltung).

Ein so verwaltetes FIFO, in dem sich bereits 5 Nutz-Daten befinden,
stellt sich als einfach verkettete Liste, inklusive der FIFO-Verwaltung,
wie folgt dar:

fuellstand: 5

letztes_element:----------------------------------------------------+
                                                                    |
erstes_element:-+                                                   |
                |                                                   |
                |                                                   |
                v                                                   v
                +----+   +-->+----+   +-->+----+   +-->+----+   +-->+----+
                |nutz|   |   |nutz|   |   |nutz|   |   |nutz|   |   |nutz|
                |info|   |   |info|   |   |info|   |   |info|   |   |info|
                +----+   |   +----+   |   +----+   |   +----+   |   +----+
                |next|---+   |next|---+   |next|---+   |next|---+   |next|--> NULL
                +----+       +----+       +----+       +----+       +----+

Die Listenelemente sind hierbei in der Reihenfolge von links nach rechts
der Reihe nach in das FIFO geschrieben worden.


A.) Betrachten wir als nächstes was zu tun ist, wenn in ein noch leeres FIFO ein erster
Wert geschrieben wird.

1.) Ausgangssituation

fuellstand: 0

letztes_element:--> NULL

erstes_element:--> NULL


2.) Allokieren von Speicher für das einzutragende Listenelement und
    eintragen der nutzinfo in das Listenelement:

fuellstand: 0

letztes_element:--> NULL

erstes_element:--> NULL


                +----+
                |nutz|
                |info|
                +----+
                |next|--> NULL
                +----+


3.) Die Merker für erstes_element und letztes_element so "verbiegen", dass
    diese auf dieses erst Listenelement zeigen und füllstand um 1 erhöhen.

fuellstand: 1

letztes_element:---+
                   |
erstes_element:-+  |
                |  |
                |  |
                v  v
                +----+
                |nutz|
                |info|
                +----+
                |next|--> NULL
                +----+



B.) Betrachten wir als nächstes was zu tun ist, wenn ein Wert in ein nicht leeres
FIFO geschrieben wird.

1.) Ausgangssituation:

fuellstand: 4

letztes_element:---------------------------------------+
                                                       |
erstes_element:-+                                      |
                |                                      |
                |                                      |
                v                                      v
                +----+   +-->+----+   +-->+----+   +-->+----+
                |nutz|   |   |nutz|   |   |nutz|   |   |nutz|
                |info|   |   |info|   |   |info|   |   |info|
                +----+   |   +----+   |   +----+   |   +----+
                |next|---+   |next|---+   |next|---+   |next|-+
                +----+       +----+       +----+       +----+ |
                                                              +-> NULL

2.) Allokieren von Speicher für das einzutragende Listenelement und
    eintragen der nutzinfo in das Listenelement:

fuellstand: 4

letztes_element:---------------------------------------+
                                                       |
erstes_element:-+                                      |
                |                                      |
                |                                      |
                v                                      v
                +----+   +-->+----+   +-->+----+   +-->+----+       +----+
                |nutz|   |   |nutz|   |   |nutz|   |   |nutz|       |nutz|
                |info|   |   |info|   |   |info|   |   |info|       |info|
                +----+   |   +----+   |   +----+   |   +----+       +----+
                |next|---+   |next|---+   |next|---+   |next|-+     |next|-+
                +----+       +----+       +----+       +----+ |     +----+ |
                                                              +-> NULL     +-> NULL


3.) Zuerst den Zeiger next des bisher letzten Listenelementes und danach den
    Merker für letztes_element auf das neue Listenelement "verbiegen" und den
    fuellstand um 1 erhöhen.

fuellstand: 5

letztes_element:----------------------------------------------------+
                                                                    |
erstes_element:-+                                                   |
                |                                                   |
                |                                                   |
                v                                                   v
                +----+   +-->+----+   +-->+----+   +-->+----+   +-->+----+
                |nutz|   |   |nutz|   |   |nutz|   |   |nutz|   |   |nutz|
                |info|   |   |info|   |   |info|   |   |info|   |   |info|
                +----+   |   +----+   |   +----+   |   +----+   |   +----+
                |next|---+   |next|---+   |next|---+   |next|---+   |next|--> NULL
                +----+       +----+       +----+       +----+       +----+


C.) Betrachten wir als nächstes was zu tun ist, wenn ein Wert aus einem nicht leeren
FIFO gelesen wird.

1.) Ausgangssituation:

fuellstand: 5

letztes_element:----------------------------------------------------+
                                                                    |
erstes_element:-+                                                   |
                |                                                   |
                |                                                   |
                v                                                   v
                +----+   +-->+----+   +-->+----+   +-->+----+   +-->+----+
                |nutz|   |   |nutz|   |   |nutz|   |   |nutz|   |   |nutz|
                |info|   |   |info|   |   |info|   |   |info|   |   |info|
                +----+   |   +----+   |   +----+   |   +----+   |   +----+
                |next|---+   |next|---+   |next|---+   |next|---+   |next|--> NULL
                +----+       +----+       +----+       +----+       +----+


2.) Wert des ersten Listenelementes lesen.
    Zunächst in einem temporären Merker (Zeiger) die Anfangsadresse des ersten
    Listenelementes merken (merker=erstes_element) dann den Merker für
    erstes_element auf das zweite Listenelement verbiegen.

fuellstand: 5

letztes_element:----------------------------------------------------+
                                                                    |
erstes_element:--------------+                                      |
                             |                                      |
merker:---------+            |                                      |
                |            |                                      |
                v            v                                      v
                +----+   +-->+----+   +-->+----+   +-->+----+   +-->+----+
                |nutz|   |   |nutz|   |   |nutz|   |   |nutz|   |   |nutz|
                |info|   |   |info|   |   |info|   |   |info|   |   |info|
                +----+   |   +----+   |   +----+   |   +----+   |   +----+
                |next|---+   |next|---+   |next|---+   |next|---+   |next|--> NULL
                +----+       +----+       +----+       +----+       +----+


3.) Den Speicher für das bisher erste Listenelement, also der Speicher auf
    den merker "zeigt" freigeben und den Fuellstand um 1 erniedrigen.

fuellstand: 4

letztes_element:----------------------------------------------------+
                                                                    |
erstes_element:--------------+                                      |
                             |                                      |
                             |                                      |
                             |                                      |
                             v                                      v
                             +----+   +-->+----+   +-->+----+   +-->+----+
                             |nutz|   |   |nutz|   |   |nutz|   |   |nutz|
                             |info|   |   |info|   |   |info|   |   |info|
                             +----+   |   +----+   |   +----+   |   +----+
                             |next|---+   |next|---+   |next|---+   |next|--> NULL
                             +----+       +----+       +----+       +----+

Abschließende Bemerkung:
In den obigen Beispielen zeigen nicht initialisierte zeiger
immer auf den Wert NULL. NULL bedeutet hier also "nicht initialisiert".
Wenn in der Implementierung des FIFOs ein leeres FIFO ausschlieslich anhand
des Füllstandes erkannt wird, so ist es nicht unbedingt notwendig, dass nicht
initialisierte Zeiger auf (mit) NULL "gebogen" (initilisiert) werden müssen.
*/



// Struktur und Typ für die Listenelemente definieren
typedef struct _listenelement {
    int nutzinfo;
    struct _listenelement *next;
} listenelement;

// Struktur und Typ für die FIFO-Verwaltung definieren
typedef struct _fifo_verwaltung {
    listenelement *letztes_element;
    listenelement *erstes_element;
    unsigned int fuellstand;
} fifo_verwaltung;


// Funktion zum eintragen einen Wertes in das FIFO, bzw. zum
// anhängen eines Listenelementes an die einfach verkettete Liste.
int an_liste_anhaengen(fifo_verwaltung *fifo, int anzuhaengender_wert) {

    listenelement *zeiger_auf_neues_listenelement;

    //### Schritt A2.) bzw. B2.)
    zeiger_auf_neues_listenelement=malloc(sizeof(listenelement));
    if(zeiger_auf_neues_listenelement==0) {
        return (-1);
    }
    zeiger_auf_neues_listenelement->nutzinfo=anzuhaengender_wert;

    if(fifo->fuellstand==0) {
        //### Schritt A3.)
        fifo->letztes_element= zeiger_auf_neues_listenelement;
        fifo->erstes_element= zeiger_auf_neues_listenelement;
        fifo->fuellstand=fifo->fuellstand+1;
    }
    else {
        //### Schritt B3.)
        fifo->letztes_element->next=zeiger_auf_neues_listenelement;
        fifo->letztes_element= zeiger_auf_neues_listenelement;
        fifo->fuellstand=fifo->fuellstand+1;
    }

    return(0);

}

// Funktion zum lesen eines Wertes aus dem FIFO, bzw. zum lesen
// und anschliessenden löschen des ersten Listenelementes der
// einfach verkettete Liste.
int erstes_listenelement_lesen_und_loeschen(fifo_verwaltung *fifo, int *gelesener_wert) {

    listenelement* merker;

    if( fifo->fuellstand==0 ) {
        return(-1);				// FIFO ist leer => Fehlerwert zurück geben
    }
    else {

        //### Schritt C2.)
        *gelesener_wert=fifo->erstes_element->nutzinfo;
        merker=fifo->erstes_element;
        fifo->erstes_element=fifo->erstes_element->next;

        //### Schritt C3.)
        free (merker);
        fifo->fuellstand=fifo->fuellstand-1;

        return(0);
    }
}



int main() {
    int lese_puffer;
    fifo_verwaltung* fifo_1; // Zeiger auf die FIFO-Verwaltung

    //### Ausgangssituation gemäß A1.) herstellen
    fifo_1=malloc(sizeof(fifo_verwaltung)); // Speicher für die FIFO-Verwaltung allokieren
    if (fifo_1==NULL) {
        printf("Fehler: Speicher für die Fifo_Verwaltung kann nicht angelegt werden.\n");
        return(-1);
    }
    fifo_1->fuellstand=0;



    //### Versuch aus einem leeren FIFO zu lesen.
    if (erstes_listenelement_lesen_und_loeschen(fifo_1, &lese_puffer)!=0)
        printf("Fehler: Aus dem Fifo konnte nicht gelesen werden.\n");
    else
        printf("Aus dem Fifo wurde der Wert %d gelesen.\n", lese_puffer);


    //### Schreiben eines ersten Wertes in das FIFO und sofort den einzigen Wert
    //    der dann im FIFO steht wieder auslesen.
    if (an_liste_anhaengen(fifo_1, 1)!=0)
        printf("Fehler: In das Fifo konnte nicht geschrieben werden.n");

    if (erstes_listenelement_lesen_und_loeschen(fifo_1, &lese_puffer)!=0)
        printf("Fehler: Aus dem Fifo konnte nicht gelesen werden.\n");
    else
        printf("Aus dem Fifo wurde der Wert %d gelesen.\n", lese_puffer);


    //### Schreiben von drei Werte in das FIFO und sofort den ersten und
    //    zweiten Wert wieder auslesen.
    if (an_liste_anhaengen(fifo_1, 1)!=0)
        printf("Fehler: In das Fifo konnte nicht geschrieben werden.n");
    if (an_liste_anhaengen(fifo_1, 2)!=0)
        printf("Fehler: In das Fifo konnte nicht geschrieben werden.n");
    if (an_liste_anhaengen(fifo_1, 3)!=0)
        printf("Fehler: In das Fifo konnte nicht geschrieben werden.n");

    if (erstes_listenelement_lesen_und_loeschen(fifo_1, &lese_puffer)!=0)
        printf("Fehler: Aus dem Fifo konnte nicht gelesen werden.\n");
    else
        printf("Aus dem Fifo wurde der Wert %d gelesen.\n", lese_puffer);

    if (erstes_listenelement_lesen_und_loeschen(fifo_1, &lese_puffer)!=0)
        printf("Fehler: Aus dem Fifo konnte nicht gelesen werden.\n");
    else
        printf("Aus dem Fifo wurde der Wert %d gelesen.\n", lese_puffer);

    //### Füllstand des FIFOs zur Überprüfung ausgeben.
    printf("Der Fuellstand des FIFOs ist %d\n", fifo_1->fuellstand);


    //### Nun auch den letzten noch im FIFO vorhandenen Wert auslesen.
    if (erstes_listenelement_lesen_und_loeschen(fifo_1, &lese_puffer)!=0)
        printf("Fehler: Aus dem Fifo konnte nicht gelesen werden.\n");
    else
        printf("Aus dem Fifo wurde der Wert %d gelesen.\n", lese_puffer);

    //### Füllstand des FIFOs zur Überprüfung ausgeben.
    printf("Der Fuellstand des FIFOs ist %d\n", fifo_1->fuellstand);

    free(fifo_1);

    getch();
    return(0);

}

#endif //beispiel_22


